مقلـة طوخ الجديدة - نسخة مشروع Flutter (مبدئية)
==========================================

هذا المشروع جاهز كنسخة مبدئية لتطبيق Android بلغة عربية (RTL).
يحتوي على:
- شاشة تسجيل الدخول (Firebase Auth)
- شاشة المنتجات (عرض + إضافة)
- شاشة المبيعات (اختيار سعر من 3 أسعار، حفظ فاتورة، تحديث كمية)
- تكامل مع Firebase Firestore (تحتاج لإعداد Firebase خارجي)

ملاحظات مهمة قبل البناء:
1) هذا المشروع **لا يتضمن** مجلد android/ الكامل. بعض خدمات البناء (مثل Codemagic) تحتاج مجلد android لعمل APK.
   - **خيار 1 (سهل):** افتح مشروع جديد على Replit واختر قالب Flutter. ثم انسخ محتويات هذا المشروع إلى مجلد lib/ واحتفظ بملف pubspec.yaml. بعد ذلك شغل:
     ```
     flutter pub get
     flutter build apk --release
     ```
   - **خيار 2 (أفضل للبناء التلقائي):** ارفع هذا المشروع إلى GitHub ثم استعمل Codemagic لربط الريبو وعمل Build. قبل البناء قد تحتاج لإضافة مجلد android أو إعداد Codemagic ليستخدم Flutter create.

2) إعداد Firebase (مهم للتشغيل الكامل):
   - اذهب إلى https://console.firebase.google.com وأنشئ مشروعًا.
   - أضف تطبيق Android واحصل على ملف google-services.json وضعه في android/app/ (عند تهيئة android).
   - شغِّل Firestore وأنشئ قواعد ملائمة أثناء التطوير (أو قواعد مؤقتة).
   - بدِّل إعدادات rules قبل الإنتاج.

3) خطوات سريعة لاستخدام Replit:
   - افتح Replit، أنشئ Repl جديد واختر Flutter.
   - انسخ ملفات lib/main.dart و lib/auth_and_sales.dart و pubspec.yaml من هذا ZIP إلى Replit.
   - شغّل في التيرمنال:
     ```
     flutter pub get
     flutter build apk --release
     ```
   - بعد الانتهاء ستجد APK في build/app/outputs/flutter-apk/app-release.apk

4) إن أردت، أقدر أجهز لك:
   - نسخة كاملة مع android/ لكي ترفعها مباشرة على Codemagic و تحصل على APK جاهز. (يتطلب وقت أكثر لأن إعداد android يحتاج إعدادات package name و keystore).
   - أو أرفع المشروع إلى GitHub لك مباشرة لو أعطيتني موافقة لنشر الريبو.

لو تحب أجهز لك نسخة كاملة (بما في ذلك android) جاهزة تمامًا للفورمات على Codemagic، قولي وهابدأ أجهزها — لكنها ستحتاج تحديد `applicationId` (مثال: com.example.mqala_toukh) وملف keystore لو عايز توقيع رسمي.
