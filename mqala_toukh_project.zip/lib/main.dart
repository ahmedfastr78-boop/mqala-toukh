// ملف: main.dart (مُحدَّث)
// نسخة مبدئية لتطبيق "مقلة طوخ الجديدة" (Android - Flutter) - باللغة العربية
// ملاحظة: هذه نسخة مبدأية للتجريب. تحتاج إلى إعداد Firebase (Android) وربط المشروع قبل التشغيل.

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'auth_and_sales.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MqalaToukhApp());
}

class MqalaToukhApp extends StatefulWidget {
  const MqalaToukhApp({Key? key}) : super(key: key);

  @override
  State<MqalaToukhApp> createState() => _MqalaToukhAppState();
}

class _MqalaToukhAppState extends State<MqalaToukhApp> {
  final AuthService _authService = AuthService();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'مقلة طوخ الجديدة',
      theme: ThemeData(
        primaryColor: const Color(0xFF1E3A8A),
        colorScheme: ColorScheme.fromSwatch().copyWith(
          primary: const Color(0xFF1E3A8A),
          secondary: const Color(0xFF3B82F6),
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F6F8),
        fontFamily: 'Roboto',
      ),
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: StreamBuilder(
          stream: _authService.authStateChanges(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
            final user = snapshot.data;
            if (user == null) {
              return LoginPage(authService: _authService);
            } else {
              return const AppHome();
            }
          },
        ),
      ),
    );
  }
}

class AppHome extends StatefulWidget {
  const AppHome({Key? key}) : super(key: key);

  @override
  State<AppHome> createState() => _AppHomeState();
}

class _AppHomeState extends State<AppHome> {
  int _selectedIndex = 0;
  final List<Widget> _pages = [const ProductsPage(), const SalesPage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مقلة طوخ الجديدة')),
      drawer: Drawer(
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: ListView(
            children: [
              DrawerHeader(
                decoration: BoxDecoration(color: Theme.of(context).primaryColor),
                child: const Text('القائمة', style: TextStyle(color: Colors.white, fontSize: 20)),
              ),
              ListTile(
                leading: const Icon(Icons.inventory_2),
                title: const Text('المنتجات والمخزون'),
                onTap: () { setState(() { _selectedIndex = 0; }); Navigator.pop(context); },
              ),
              ListTile(
                leading: const Icon(Icons.point_of_sale),
                title: const Text('المبيعات'),
                onTap: () { setState(() { _selectedIndex = 1; }); Navigator.pop(context); },
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('تسجيل الخروج'),
                onTap: () async {
                  await AuthService().signOut();
                },
              ),
            ],
          ),
        ),
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (i) => setState(() => _selectedIndex = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.inventory_2), label: 'المنتجات'),
          BottomNavigationBarItem(icon: Icon(Icons.point_of_sale), label: 'المبيعات'),
        ],
      ),
    );
  }
}
