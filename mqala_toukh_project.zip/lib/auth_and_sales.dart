// ملف: auth_and_sales.dart
// يحتوي على تسجيل الدخول (Firebase Auth) وأنواع المستخدمين، وشاشة مبيعات بسيطة
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<User?> signIn(String email, String password) async {
    final cred = await _auth.signInWithEmailAndPassword(email: email, password: password);
    return cred.user;
  }

  Future<User?> signUp(String email, String password, String role, String name) async {
    final cred = await _auth.createUserWithEmailAndPassword(email: email, password: password);
    final user = cred.user;
    if (user != null) {
      await _firestore.collection('users').doc(user.uid).set({
        'email': email,
        'name': name,
        'role': role, // 'manager' or 'cashier'
        'created_at': FieldValue.serverTimestamp(),
      });
    }
    return user;
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  Stream<User?> authStateChanges() => _auth.authStateChanges();
}

class LoginPage extends StatefulWidget {
  final AuthService authService;
  const LoginPage({Key? key, required this.authService}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل الدخول')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            TextField(controller: _email, decoration: const InputDecoration(labelText: 'البريد الإلكتروني')),
            TextField(controller: _password, decoration: const InputDecoration(labelText: 'كلمة المرور'), obscureText: true),
            const SizedBox(height: 12),
            if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
            ElevatedButton(
              onPressed: _loading ? null : _login,
              child: _loading ? const CircularProgressIndicator() : const Text('دخول'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _login() async {
    try {
      setState(() { _loading = true; _error = null; });
      final user = await widget.authService.signIn(_email.text.trim(), _password.text.trim());
      if (user == null) throw Exception('فشل تسجيل الدخول');
      // بعد النجاح، يحصل التطبيق على بيانات role من collection users
      final doc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final role = doc.data()?['role'] ?? 'cashier';
      // توجه للشاشة الرئيسية مع تمرير الدور
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomeAfterLogin(role: role)));
    } catch (e) {
      setState(() { _error = e.toString(); });
    } finally { setState(() { _loading = false; }); }
  }
}

class HomeAfterLogin extends StatelessWidget {
  final String role;
  const HomeAfterLogin({Key? key, required this.role}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('مرحبًا - الدور: $role')),
      body: Center(child: Text('الواجهة الرئيسية (أضف روابط المبيعات، المنتجات، إلخ)')),
    );
  }
}

// شاشة المبيعات البسيطة
class SalesPage extends StatefulWidget {
  const SalesPage({Key? key}) : super(key: key);

  @override
  State<SalesPage> createState() => _SalesPageState();
}

class _SalesPageState extends State<SalesPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final List<Map<String, dynamic>> _cart = [];
  String? _selectedCustomerId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المبيعات')),
      body: Column(
        children: [
          Expanded(child: _productsList()),
          _cartSummary(),
        ],
      ),
    );
  }

  Widget _productsList() {
    return StreamBuilder<QuerySnapshot>(
      stream: _firestore.collection('products').orderBy('name').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snapshot.data!.docs;
        return ListView.builder(
          itemCount: docs.length,
          itemBuilder: (context, i) {
            final d = docs[i].data() as Map<String, dynamic>;
            return ListTile(
              title: Text(d['name'] ?? ''),
              subtitle: Text('الكمية: ${d['quantity'] ?? 0} - أسعار: ${d['price_1']}/${d['price_2']}/${d['price_3']}'),
              trailing: IconButton(icon: const Icon(Icons.add_shopping_cart), onPressed: () => _addToCart(d, docs[i].id)),
            );
          },
        );
      },
    );
  }

  Future<void> _addToCart(Map<String, dynamic> product, String productId) async {
    // طلب الكمية والسعر المطلوب (اختيار السعر من 1/2/3)
    final qtyCtrl = TextEditingController(text: '1');
    int selectedPriceIndex = 1;

    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('إضافة إلى الفاتورة - ${product['name']}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: qtyCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الكمية')),
            const SizedBox(height: 8),
            StatefulBuilder(builder: (ctx, st) {
              return Column(children: [
                RadioListTile<int>(value: 1, groupValue: selectedPriceIndex, title: Text('سعر 1 - ${product['price_1']}'), onChanged: (v) => st(() => selectedPriceIndex = v!)),
                RadioListTile<int>(value: 2, groupValue: selectedPriceIndex, title: Text('سعر 2 - ${product['price_2']}'), onChanged: (v) => st(() => selectedPriceIndex = v!)),
                RadioListTile<int>(value: 3, groupValue: selectedPriceIndex, title: Text('سعر 3 - ${product['price_3']}'), onChanged: (v) => st(() => selectedPriceIndex = v!)),
              ]);
            })
          ],
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('إضافة'))],
      ),
    );

    if (ok != true) return;
    final qty = int.tryParse(qtyCtrl.text) ?? 1;
    final priceField = 'price_$selectedPriceIndex';
    final price = (product[priceField] ?? product['price_1'])?.toDouble() ?? 0.0;

    setState(() {
      _cart.add({
        'product_id': productId,
        'name': product['name'],
        'qty': qty,
        'price_index': selectedPriceIndex,
        'unit_price': price,
        'subtotal': qty * price,
      });
    });
  }

  Widget _cartSummary() {
    final total = _cart.fold<double>(0.0, (p, e) => p + (e['subtotal'] as num).toDouble());
    return Container(
      padding: const EdgeInsets.all(12),
      color: Colors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('عدد الأصناف: ${_cart.length}'), Text('الإجمالي: ${total.toStringAsFixed(2)}')]),
          const SizedBox(height: 8),
          Row(children: [Expanded(child: ElevatedButton(onPressed: _cart.isEmpty ? null : _checkout, child: const Text('حفظ الفاتورة')))]),
        ],
      ),
    );
  }

  Future<void> _checkout() async {
    // تقوم بحفظ الفاتورة في collection 'sales' وتحديث كميات المنتجات
    final batch = _firestore.batch();
    final saleRef = _firestore.collection('sales').doc();
    final saleItems = _cart.map((e) => {
      'product_id': e['product_id'],
      'name': e['name'],
      'qty': e['qty'],
      'price_index': e['price_index'],
      'unit_price': e['unit_price'],
      'subtotal': e['subtotal'],
    }).toList();

    final total = _cart.fold<double>(0.0, (p, e) => p + (e['subtotal'] as num).toDouble());

    batch.set(saleRef, {
      'items': saleItems,
      'total': total,
      'customer_id': _selectedCustomerId ?? '',
      'date': FieldValue.serverTimestamp(),
      'user_id': FirebaseAuth.instance.currentUser?.uid ?? '',
    });

    // تحديث الكميات
    for (var item in _cart) {
      final prodRef = _firestore.collection('products').doc(item['product_id']);
      batch.update(prodRef, {'quantity': FieldValue.increment(-item['qty'])});
    }

    await batch.commit();

    // تفريغ العربة
    setState(() { _cart.clear(); });

    // إشعار نجاح
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ الفاتورة بنجاح')));
  }
}
